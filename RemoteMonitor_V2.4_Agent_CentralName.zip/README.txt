Remote Monitor V2.4 - Updated Agent

This Agent build removes local Agent Name entry/storage.
Agent naming is intended to be managed centrally from the Server/Admin Viewer.

Install/update:
1. Stop the old Agent.
2. Replace the existing Agent program files with these files.
3. Keep the existing V2.4 root config.json unchanged.
4. Start START_AGENT.bat.

Do not copy or replace config.json with this Agent package.
