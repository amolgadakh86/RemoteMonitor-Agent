@echo off
cd /d "%~dp0"
if not exist "%~dp0venv\Scripts\python.exe" (
  py -m venv "%~dp0venv"
  call "%~dp0venv\Scripts\python.exe" -m pip install --upgrade pip
  call "%~dp0venv\Scripts\python.exe" -m pip install -r "%~dp0requirements.txt"
)
"%~dp0venv\Scripts\python.exe" "%~dp0agent.py"
pause
