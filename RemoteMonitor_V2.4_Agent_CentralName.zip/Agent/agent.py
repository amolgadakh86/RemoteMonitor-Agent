import json, time, uuid, socket, io, os, getpass
from pathlib import Path
import requests, websocket
from PIL import ImageGrab

BASE = Path(__file__).resolve().parent.parent
CFG = json.loads((BASE/"config.json").read_text(encoding="utf-8"))
SERVER = CFG["server_url"].rstrip("/")
TOKEN = CFG["agent_token"]
RECONNECT = float(CFG.get("reconnect_seconds",10))
INTERVAL = float(CFG.get("frame_interval_seconds",1))

STATE = Path(__file__).resolve().parent / "state"
STATE.mkdir(exist_ok=True)
ID_FILE = STATE/"agent_id.txt"
HOST_FILE = STATE/"host_name.txt"
NC_FILE = STATE/"ncomputing.txt"

if ID_FILE.exists():
    AGENT_ID = ID_FILE.read_text(encoding="utf-8").strip()
else:
    AGENT_ID = str(uuid.uuid4())
    ID_FILE.write_text(AGENT_ID, encoding="utf-8")

PC_NAME = socket.gethostname()
AGENT_NAME = PC_NAME
HOST_NAME = HOST_FILE.read_text(encoding="utf-8").strip() if HOST_FILE.exists() else ""
NCOMPUTING = NC_FILE.exists() and NC_FILE.read_text(encoding="utf-8").strip().lower() == "true"

REGISTER = SERVER+"/agent/register"
WSURL = SERVER.replace("https://","wss://").replace("http://","ws://") + f"/agent/{AGENT_ID}?token={TOKEN}"

def register():
    r = requests.post(REGISTER, json={
        "agent_id": AGENT_ID,
        "pc_name": PC_NAME, "host_name": HOST_NAME,
        "ncomputing": NCOMPUTING
    }, headers={"X-Agent-Token":TOKEN}, timeout=10)
    r.raise_for_status()
    print(f"[REGISTERED] {PC_NAME} | {AGENT_ID}")

def capture():
    img = ImageGrab.grab()
    if img.width > 1280:
        h = int(img.height * 1280 / img.width)
        img = img.resize((1280,h))
    b = io.BytesIO()
    img.save(b, format="JPEG", quality=65, optimize=True)
    return b.getvalue()

while True:
    try:
        register()
        ws = websocket.create_connection(WSURL, timeout=15)
        print(f"[CONNECTED] {PC_NAME}")
        while True:
            ws.send_binary(capture())
            time.sleep(INTERVAL)
    except Exception as e:
        print(f"[DISCONNECTED] {e}")
        print(f"Retrying in {RECONNECT:g} seconds...")
        try: ws.close()
        except: pass
        time.sleep(RECONNECT)
