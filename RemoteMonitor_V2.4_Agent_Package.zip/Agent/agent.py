import asyncio, io, json, os, socket, time, uuid, traceback
from pathlib import Path

import requests
import websockets
from PIL import ImageGrab

BASE = Path(__file__).resolve().parent
CONFIG = BASE / "config.json"
STATE = BASE / "state"
STATE.mkdir(exist_ok=True)
LOG = BASE / "agent.log"

def log(*parts):
    msg = time.strftime("%Y-%m-%d %H:%M:%S") + " | " + " ".join(str(x) for x in parts)
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except Exception:
        pass
    print(msg, flush=True)

def load_config():
    with open(CONFIG, "r", encoding="utf-8-sig") as f:
        return json.load(f)

cfg = load_config()
SERVER_URL = cfg.get("server_url", "http://127.0.0.1:8765").rstrip("/")
AGENT_TOKEN = cfg.get("agent_token", "").strip()
RECONNECT = max(5, int(cfg.get("reconnect_seconds", 10)))
FRAME_INTERVAL = max(0.2, float(cfg.get("frame_interval_seconds", 1.0)))

id_file = STATE / "agent_id.txt"
if id_file.exists():
    agent_id = id_file.read_text(encoding="utf-8").strip()
else:
    agent_id = str(uuid.uuid4())
    id_file.write_text(agent_id, encoding="utf-8")

def register():
    if not AGENT_TOKEN or AGENT_TOKEN == "PUT_AGENT_TOKEN_HERE":
        raise RuntimeError("Agent token is not configured")
    payload = {
        "pc_id": agent_id,
        "pc_name": socket.gethostname(),
        "ncomputing_host": cfg.get("ncomputing_host", ""),
    }
    log("REGISTER", SERVER_URL, agent_id)
    r = requests.post(
        SERVER_URL + "/agent/register",
        json=payload,
        headers={"X-Agent-Token": AGENT_TOKEN},
        timeout=15,
    )
    r.raise_for_status()
    log("REGISTERED", r.status_code)
    return r.json()

def capture_jpeg():
    img = ImageGrab.grab(all_screens=True)
    img.thumbnail((1920, 1080))
    b = io.BytesIO()
    img.save(b, format="JPEG", quality=70, optimize=True)
    return b.getvalue()

async def stream():
    ws_url = SERVER_URL.replace("https://", "wss://").replace("http://", "ws://")
    url = f"{ws_url}/agent/{agent_id}?token={AGENT_TOKEN}"
    log("CONNECT_WS", url.split("?", 1)[0])
    async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_size=8*1024*1024) as ws:
        log("WS_CONNECTED")
        while True:
            frame = await asyncio.to_thread(capture_jpeg)
            await ws.send(frame)
            await asyncio.sleep(FRAME_INTERVAL)

def main():
    log("AGENT_START", socket.gethostname())
    while True:
        try:
            register()
            asyncio.run(stream())
        except Exception as e:
            log("ERROR", repr(e))
            try:
                log(traceback.format_exc().strip())
            except Exception:
                pass
            time.sleep(RECONNECT)

if __name__ == "__main__":
    main()
