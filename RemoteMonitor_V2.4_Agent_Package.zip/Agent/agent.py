import asyncio, io, json, os, socket, time, uuid
from pathlib import Path

import requests
import websockets
from PIL import ImageGrab

BASE = Path(__file__).resolve().parent
CONFIG = BASE / "config.json"
STATE = BASE / "state"
STATE.mkdir(exist_ok=True)

def load_config():
    with open(CONFIG, "r", encoding="utf-8") as f:
        return json.load(f)

cfg = load_config()
SERVER_URL = cfg.get("server_url", "http://127.0.0.1:8765").rstrip("/")
AGENT_TOKEN = cfg.get("agent_token", "").strip()
RECONNECT = int(cfg.get("reconnect_seconds", 10))
FRAME_INTERVAL = float(cfg.get("frame_interval_seconds", 1.0))

id_file = STATE / "agent_id.txt"
if id_file.exists():
    agent_id = id_file.read_text(encoding="utf-8").strip()
else:
    agent_id = str(uuid.uuid4())
    id_file.write_text(agent_id, encoding="utf-8")

def register():
    if not AGENT_TOKEN:
        raise RuntimeError("agent_token is empty in config.json")
    payload = {
        "pc_id": agent_id,
        "pc_name": socket.gethostname(),
        "ncomputing_host": cfg.get("ncomputing_host", ""),
    }
    r = requests.post(
        SERVER_URL + "/agent/register",
        json=payload,
        headers={"X-Agent-Token": AGENT_TOKEN},
        timeout=15,
    )
    r.raise_for_status()
    return r.json()

def capture_jpeg():
    img = ImageGrab.grab(all_screens=True)
    img.thumbnail((1920, 1080))
    b = io.BytesIO()
    img.save(b, format="JPEG", quality=70, optimize=True)
    return b.getvalue()

async def stream():
    ws_url = SERVER_URL.replace("https://", "wss://").replace("http://", "ws://")
    url = f"{ws_url}/agent/{agent_id}?token={AGENT_TOKEN}"
    async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_size=8*1024*1024) as ws:
        while True:
            frame = await asyncio.to_thread(capture_jpeg)
            await ws.send(frame)
            await asyncio.sleep(FRAME_INTERVAL)

def main():
    while True:
        try:
            register()
            asyncio.run(stream())
        except Exception as e:
            print("Agent connection error:", e)
            time.sleep(RECONNECT)

if __name__ == "__main__":
    main()
